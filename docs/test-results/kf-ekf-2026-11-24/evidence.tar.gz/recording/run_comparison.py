"""Run four paired turn trials on STM32 and restore the normal KF image."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--data-port', required=True)
parser.add_argument('--console-port', required=True)
parser.add_argument('--west', type=Path, required=True)
parser.add_argument('--workspace', type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
out = args.output.resolve()
sys.path.insert(0, str(root))
import serial
from pc_sim.simulation.prepared_input import InputSettings, generate_input
from pc_sim.storage.prepared_storage import save_input
from pc_sim.evaluation.turn_noise import run
from pc_sim.cli.status_client import request_status
spec = importlib.util.spec_from_file_location('perf_board_check', root/'fcc_app/tests/test_perf_monitor/board_check.py')
perf_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(perf_module)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def flash(build, log):
    with log.open('w') as stream:
        subprocess.run([str(args.west), 'flash', '-d', str(build), '--runner', 'openocd'],
                       cwd=args.workspace, stdout=stream, stderr=subprocess.STDOUT,
                       check=True, timeout=60)


out.mkdir(parents=True, exist_ok=False)
shutil.copy2(__file__, out/'run_comparison.py')
manifest = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
            'source_status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True),
            'board': 'stm32f746g_disco', 'data_port': args.data_port,
            'console_port': args.console_port, 'baud': 115200,
            'plan': {'cases': ['baseline', 'noisy'], 'seed': 42, 'dt_s': .1,
                     'duration_s': 80, 'scenario': 'straight_turn_straight'},
            'complete': False, 'restored': False, 'runs': [], 'builds': {}}
for case, noise, angle in [('baseline', 0, 0), ('noisy', 10, .01)]:
    prepared = generate_input(InputSettings(scenario='straight_turn_straight', duration_s=80,
                                          dt_s=.1, range_noise_std_m=noise,
                                          azimuth_noise_std_rad=angle, seed=42))
    save_input(out/'inputs'/case, prepared)
    assert len(prepared.samples) == 755
for name, directory in [('kf', 'build_compare_kf'), ('ekf', 'build_compare_ekf'), ('restore', 'build')]:
    build = root/directory/'zephyr'
    config = (build/'.config').read_text()
    assert f'CONFIG_RADAR_ESTIMATOR_{"EKF" if name == "ekf" else "KF"}_CV=y' in config
    assert ('CONFIG_RADAR_PERF_MONITOR=y' in config) == (name != 'restore')
    assert 'CONFIG_RADAR_RANGE_MEASUREMENT_VARIANCE_M_SQUARED=25\n' in config
    assert 'CONFIG_RADAR_AZIMUTH_MEASUREMENT_VARIANCE_RAD_SQUARED_SCALED_1E9=1218470\n' in config
    for filename in ['.config', 'zephyr.hex', 'zephyr.elf']:
        manifest['builds'].setdefault(name, {})[filename] = digest(build/filename)
    shutil.copy2(build/'.config', out/(name+'.config'))
    manifest['builds'][name]['directory'] = directory
    # Keep exact flashed bytes locally; public evidence can carry hashes/configs.
    shutil.copy2(build/'zephyr.hex', out/(name+'.hex'))
dump(out/'manifest.json', manifest)
try:
    for name in ['kf', 'ekf']:
        for case in ['baseline', 'noisy']:
            trial = out/name/case
            trial.mkdir(parents=True)
            stop = threading.Event()
            console_errors = []
            with serial.Serial(args.console_port, 115200, timeout=.1, exclusive=True) as console:
                console.reset_input_buffer()
                def capture():
                    try:
                        with (trial/'console.log').open('wb') as stream:
                            while not stop.is_set():
                                data = console.read(4096)
                                if data:
                                    stream.write(data)
                                    stream.flush()
                    except BaseException as error:
                        console_errors.append(repr(error))
                thread = threading.Thread(target=capture)
                thread.start()
                try:
                    print('FLASH', name, case, flush=True)
                    flash(root/manifest['builds'][name]['directory'], trial/'flash.log')
                    time.sleep(1)
                    session, result = run(args.data_port, trial/'sessions', out/'inputs'/case)
                    print('DRAIN PERF', name, case, flush=True)
                    time.sleep(6)
                finally:
                    stop.set()
                    thread.join(timeout=2)
            assert not thread.is_alive() and not console_errors, console_errors
            console_parser = perf_module.PerfConsole()
            console_parser.feed((trial/'console.log').read_text(errors='replace'))
            perf = {'boots': console_parser.boots, 'faults': console_parser.faults,
                    'incomplete_summaries': console_parser.incomplete_summaries,
                    'snapshots': console_parser.snapshots}
            dump(trial/'perf.json', perf)
            item = {'estimator': name, 'case': case, 'session': str(session.relative_to(out)),
                    'input_samples_sha256': digest(out/'inputs'/case/'samples.jsonl'),
                    'result': result, 'console_faults': console_parser.faults,
                    'boots': console_parser.boots, 'perf_snapshot_count': len(console_parser.snapshots)}
            manifest['runs'].append(item)
            dump(out/'manifest.json', manifest)
            print('DONE', name, case, json.dumps({'integrity': result['integrity_ok'],
                  'position': result['position'], 'gates': result['gate_rejected'],
                  'lost': result['lost_transitions']}), flush=True)
            assert result['integrity_ok'] and not console_parser.faults
            assert console_parser.boots == 1 and console_parser.snapshots
            assert console_parser.snapshots[-1]['header']['measurements'] == 755
    manifest['complete'] = True
finally:
    try:
        print('RESTORE normal KF', flush=True)
        flash(root/'build', out/'restore-flash.log')
        time.sleep(1)
        with serial.Serial(args.data_port, 115200, timeout=.05, write_timeout=2, exclusive=True) as data:
            status = request_status(data)
        manifest['restore_status'] = status
        manifest['restored'] = not any(status.values())
        print('RESTORED', manifest['restored'], status, flush=True)
    except BaseException as error:
        manifest['restore_error'] = repr(error)
        raise
    finally:
        dump(out/'manifest.json', manifest)
