#include "transport/uart_rx.h"

#include <errno.h>

#include <zephyr/device.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>
#include <zephyr/sys/__assert.h>
#include <zephyr/sys/atomic.h>

#include "common/ring_buffer.h"
#include "diagnostics/perf_rx_capture.h"
#include "transport/rx_frame_processor.h"

LOG_MODULE_REGISTER(uart_rx, CONFIG_RADAR_UART_RX_LOG_LEVEL);

#if defined(CONFIG_RADAR_RX_OVERFLOW_DRAIN)
#define RX_OVERFLOW_POLICY RX_OVERFLOW_POLICY_DRAIN_BUFFER
#elif defined(CONFIG_RADAR_RX_OVERFLOW_DISCARD)
#define RX_OVERFLOW_POLICY RX_OVERFLOW_POLICY_DISCARD_ALL
#else
#error "Select an RX overflow recovery policy"
#endif

// USART6 carries protocol traffic; the board console uses a separate UART.
static const struct device *p_uart = DEVICE_DT_GET(DT_NODELABEL(usart6));

static struct ring_buffer rx_ring;
struct rx_byte_sample {
    uint8_t byte;
    uint32_t stored_cycles;
};

// Caller protects the byte and its timestamp together. No clocks or statistics.
static bool rx_pop_byte(struct rx_byte_sample *out_sample)
{
    const uint8_t slot = rx_ring.tail;
    const bool available = ring_pop(&rx_ring, &out_sample->byte);
    if (available) {
        out_sample->stored_cycles = perf_rx_capture_load_byte(slot);
    }
    return available;
}

// 1 means bytes were lost: the ISR drops new input until the RX thread finishes recovery.
static atomic_t rx_overflow = ATOMIC_INIT(0);
// Bytes read from the UART FIFO but not stored because the ring is full
// or overflow recovery is active. Excludes buffered data discarded during
// recovery and bytes lost by the UART hardware.
static atomic_t rx_dropped_bytes = ATOMIC_INIT(0);
// Number of transitions into overflow recovery after a failed ring push.
static atomic_t ring_overflow_events = ATOMIC_INIT(0);
// Buffered bytes discarded by the overflow recovery.
// Excludes bytes dropped by the ISR and partial data already consumed by the parser.
static atomic_t recovery_discarded_bytes = ATOMIC_INIT(0);

// Notify the RX thread of buffered data or overflow; actual bytes remain in rx_ring.
K_SEM_DEFINE(rx_sem, 0, 1);
// Keep the RX thread waiting until the ring and parser are initialized.
// The handler initializes its own state in its processing thread.
K_SEM_DEFINE(rx_ready_sem, 0, 1);

static void uart_callback(const struct device *p_dev, void *p_user_data);
static void uart_rx_thread(void *p_arg1, void *p_arg2, void *p_arg3);

static void rx_recover_discard_all(void);
static void rx_recover_drain_buffer(void);
static void rx_recover_overflow(void);
static void rx_finish_recovery(void);

K_THREAD_DEFINE(uart_rx_tid, 1024, uart_rx_thread, NULL, NULL, NULL, 5, 0, 0);

int uart_rx_init(void)
{
    const bool device_ready = device_is_ready(p_uart);
    if (!device_ready) {
        LOG_ERR("UART init: uart=USART6 status=not_ready");
        return -ENODEV;
    }

    const int ret = uart_irq_callback_user_data_set(p_uart, uart_callback, NULL);
    if (ret != 0) {
        LOG_ERR("UART callback: status=failed error=%d", ret);
        return ret;
    }

    ring_init(&rx_ring);

    // Initialize partial-frame state before enabling the ISR.
    rx_frame_processor_reset();

    perf_rx_capture_init();
    uart_irq_rx_enable(p_uart);

    // Bytes may already be buffered by the ISR; the initialized ring retains them.
    k_sem_give(&rx_ready_sem);

    return 0;
}

void uart_rx_get_stats(struct uart_rx_stats *out_stats)
{
    __ASSERT(out_stats != NULL, "Output stats pointer is NULL");

    out_stats->ring_overflow_events =
        (uint32_t)atomic_get(&ring_overflow_events);
    out_stats->rx_dropped_bytes =
        (uint32_t)atomic_get(&rx_dropped_bytes);
    out_stats->recovery_discarded_bytes =
        (uint32_t)atomic_get(&recovery_discarded_bytes);
}

static void uart_callback(const struct device *p_dev, void *p_user_data)
{
    ARG_UNUSED(p_user_data);
    const uint32_t start = perf_rx_capture_now();

    // Refresh interrupt status before querying pending/ready flags.
    uart_irq_update(p_dev);

    while (uart_irq_is_pending(p_dev)) {
        const int rx_ready = uart_irq_rx_ready(p_dev);
        if (rx_ready) {
            uint8_t byte;
            while (uart_fifo_read(p_dev, &byte, 1) == 1) {
                const uint32_t stored_cycles = perf_rx_capture_now();
                // Keep draining the hardware FIFO during recovery, but discard new bytes.
                // Drain recovery requires the buffer to contain only bytes received before the first loss.
                const atomic_val_t overflow = atomic_get(&rx_overflow);
                if (overflow != 0) {
                    atomic_inc(&rx_dropped_bytes);
                    continue;
                }

                const uint8_t slot = rx_ring.head;
                const bool byte_stored = ring_push(&rx_ring, byte);
                if (byte_stored) {
                    perf_rx_capture_store_byte(slot, stored_cycles);
                }
                if (!byte_stored) {
                    atomic_inc(&ring_overflow_events);
                    atomic_inc(&rx_dropped_bytes);
                    // Drop the byte that could not be stored and mark recovery as required.
                    atomic_set(&rx_overflow, 1);
                }
                // Wake the thread on successful storage or the first overflow.
                k_sem_give(&rx_sem);
            }
        }
    }
    perf_rx_capture_isr(start, perf_rx_capture_now());
}

static void uart_rx_thread(void *p_arg1, void *p_arg2, void *p_arg3)
{
    ARG_UNUSED(p_arg1);
    ARG_UNUSED(p_arg2);
    ARG_UNUSED(p_arg3);

    // Wait for RX initialization to complete
    k_sem_take(&rx_ready_sem, K_FOREVER);

    while (1) {
        // Wake on RX notification, or after 50 ms even when no data arrives.
        // This wait interval is separate from the measurement timeout threshold.
        // A timeout is an expected wakeup; both wake reasons run the same drain/check path.
        k_sem_take(&rx_sem, K_MSEC(50));

        while (1) {
            perf_rx_capture_collect_isr();
            struct rx_byte_sample sample;

            // Protect the overflow check and single-byte ring pop from the UART ISR.
            // Parsing and queue submission run after interrupts are restored.
            const unsigned int key = irq_lock();

            const atomic_val_t overflow = atomic_get(&rx_overflow);
            if (overflow != 0) {
                // Allow interrupts during parsing, queue submission, and logging in drain recovery.
                // The flag remains set, so the ISR still cannot write to the ring buffer.
                irq_unlock(key);

                rx_recover_overflow();

                struct uart_rx_stats stats;
                uart_rx_get_stats(&stats);
                // Cumulative values are individually atomic, not one snapshot.
                LOG_WRN("RX overflow: recovery=completed events=%u isr_dropped_bytes=%u recovery_discarded_bytes=%u",
                        (unsigned int)stats.ring_overflow_events,
                        (unsigned int)stats.rx_dropped_bytes,
                        (unsigned int)stats.recovery_discarded_bytes);

                break;
            }

            const bool byte_available = rx_pop_byte(&sample);
            if (!byte_available) {
                irq_unlock(key);
                break;
            }

            irq_unlock(key);

            perf_rx_capture_collect_byte(sample.stored_cycles);
            rx_frame_processor_feed(sample.byte);
        }

        rx_frame_processor_handle_timeout(k_uptime_get());
    }
}

static void rx_recover_discard_all(void)
{
    // Discard all buffered data immediately, including any valid frames.
    rx_finish_recovery();
}

static void rx_recover_drain_buffer(void)
{
    struct rx_byte_sample sample;

    // While overflow is set, the ISR does not store bytes; only this thread accesses the buffer.
    // Preserve parser state to complete frames using bytes received before the loss.
    // New bytes arriving during processing are dropped by the ISR; recovery is not lossless.
    while (rx_pop_byte(&sample)) {
        perf_rx_capture_collect_byte(sample.stored_cycles);
        rx_frame_processor_feed(sample.byte);
    }

    // Discard any incomplete frame remaining after the buffer has been drained.
    rx_finish_recovery();
}

static void rx_recover_overflow(void)
{
    // Call from the RX thread with interrupts enabled and the overflow flag set.
    switch (RX_OVERFLOW_POLICY) {
    case RX_OVERFLOW_POLICY_DISCARD_ALL:
        rx_recover_discard_all();
        break;
    case RX_OVERFLOW_POLICY_DRAIN_BUFFER:
        rx_recover_drain_buffer();
        break;
    default:
        // For an unknown policy, perform discard recovery before clearing the flag.
        rx_recover_discard_all();
        break;
    }
}

static void rx_finish_recovery(void)
{
    // Only the RX thread owns parser state; overflow keeps ISR stores disabled.
    rx_frame_processor_reset();
    // Protect only shared ring indices and overflow state.
    const unsigned int key = irq_lock();

    // Count unread bytes before clearing the ring.
    // Drain recovery normally leaves no unread bytes.
    // At most 255 buffered bytes fit in both uint32_t and atomic_val_t.
    const uint32_t discarded_bytes = (uint32_t)((rx_ring.head + RING_BUFFER_SIZE - rx_ring.tail) % RING_BUFFER_SIZE);
    atomic_add(&recovery_discarded_bytes, (atomic_val_t)discarded_bytes);

    // Clear the software buffer and partial frame, then resume searching for PROTOCOL_STX.
    // This does not flush the hardware FIFO or guarantee alignment with the next frame.
    ring_init(&rx_ring);

    // Allow the ISR to store bytes only after all recovery state has been reset.
    atomic_clear(&rx_overflow);

    irq_unlock(key);
}
